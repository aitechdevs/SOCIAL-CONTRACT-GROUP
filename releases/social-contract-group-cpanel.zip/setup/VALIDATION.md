# Validation

Validated locally using PHP 8.3, Apache 2.4 with mod_rewrite, and MariaDB 11.4. No Node.js runtime or build dependency.

Passed:
- PHP syntax checks for all application PHP files.
- 15 public routes, unknown-route 404, authenticated-route redirects.
- Registration, login, member dashboard, logout, non-admin 403.
- Positive administrator access, member count and persisted enquiry display.
- Contact and volunteer database insertion; CSRF rejection.
- Eight private paths/listings denied by Apache; security headers present.
- Desktop and 390px mobile browser checks, menu open/close, four slider states, policy filtering and state search.
- No browser JavaScript errors or horizontal overflow in checked pages.
- Package excludes local database credentials, Git metadata, and test data.

All generated test accounts and enquiries were removed from the local development database. No production account or default administrator was created.

Not verified: deployment to the actual cPanel host, domain/DNS/TLS configuration, new cloud-task restoration, the accuracy of policy claims and reference links, real chapter contacts or event schedules. Payment processing, email verification, password recovery and a publishing CMS are not implemented. Admin is a read-only overview.

SEO update: passed 11 sitemap/canonical URL checks, unique titles/descriptions, structured data parsing, social-preview PNG serving, noindex coverage, robots rules, production HTTP/www redirects and private SEO/helper file protection. Google ownership verification, sitemap submission and live-host validation remain pending; the environment's DNS/proxy prevented live-domain checks.

Editorial image update: used nine supplied WebP illustrations, mapped by visible content. Passed home/news topic filters (including keyboard activation), four image slider states, image-load checks, 360/390/768/1024/1440px overflow checks, reduced-motion behaviour, PHP lint, public-route smoke checks, SEO and Apache protection checks. ChromeUnboxed could not be fetched because the proxy returned 403; the design follows the user-described visual traits rather than a verified current rendering.

Full-name logo update: verified the 2172 × 724 RGBA master has transparency and is served unchanged; both header/footer wordmarks, the SCG favicon and Organization logo metadata are correct. Desktop/mobile browser, resource filters, sliders, SEO and Apache security checks passed. Publication master is PNG raster artwork, not an editable vector file.

Clean URL and text-free revision: passed 16 public-route checks, direct 404 checks, six legacy/slash redirects, registration/login/contact/volunteer/logout over clean paths, 12 clean sitemap/canonical URLs, private-source protection and browser controls. Nine image edits were visually reviewed for lettering removal. Captions/source banners are removed and provenance is consolidated on /image-credits. New image URLs avoid prior browser caches.

Artifact check: extracted the full current cPanel ZIP with its declared 644/755 modes and served it under a separate Apache worker UID. Clean home/about/projects/credits pages, CSS, edited WebP and logo PNG returned HTTP 200 with correct media types. Temporary artifact-test container was removed afterward.


Homepage refresh (2026-10-23): new buffered crossfade/zoom carousel, content-hashed front-end assets, owner-supplied Roboto Condensed and Fjalla One typography, wider layout, and four revised illustrations. Homepage checks passed at six viewport sizes including mobile and landscape; reduced motion, keyboard and pause controls passed. Browser, clean-route, SEO and Apache access checks passed. Reference site inspection was blocked; no exact animation match or photographic authenticity is claimed.

Roboto Condensed and Fjalla One are bundled locally with SIL licenses; browser font-load checks passed. The extracted full ZIP passed homepage and public smoke checks under a separate Apache instance. All eight release ZIPs passed permissions and integrity checks. PHP syntax passed inside the PHP container.


Office contacts/captions update: PHP syntax, six viewport homepage checks, browser interactions, public smoke, clean routes, SEO and private-path checks passed. Captured-mail integration proved persistence, both recipients, validated Reply-To, and resistance to header injection via the visitor name. Simulated transport failure retained the stored enquiry and displayed fallback contact information. No external test emails sent; live hosting delivery remains to be checked by the operator.
